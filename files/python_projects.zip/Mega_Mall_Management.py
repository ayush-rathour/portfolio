# ======================================================
# 🏬 MEGA MALL MANAGEMENT SYSTEM
# ======================================================


# ======================================================
# 👤 CUSTOMER DETAILS
# ======================================================

customer_name = input("👤 Customer Name → ")

customer_age = int(input("🎂 Customer Age → "))

if customer_age <= 0:
    print("❌ Invalid Age!")
    exit()


# ======================================================
# 🛒 SHOPPING CATEGORY
# ======================================================

category_choice = int(input("""
========== 🛒 CATEGORIES ==========

1. Electronics
2. Clothing
3. Grocery
4. Food Court

Choose Category → """))


match category_choice:

    case 1:
        category_name = "Electronics"

    case 2:
        category_name = "Clothing"

    case 3:
        category_name = "Grocery"

    case 4:
        category_name = "Food Court"

    case _:
        print("❌ Invalid Shopping Category!")
        exit()


# ======================================================
# 🛍️ ITEM MENU
# ======================================================

match category_name:

    case "Electronics":

        item_choice = int(input("""
========== 💻 ELECTRONICS ==========

1. Headphones      → ₹1500
2. Smart Watch     → ₹3000
3. Keyboard        → ₹800
4. Mouse           → ₹500

Choose Item → """))

    case "Clothing":

        item_choice = int(input("""
========== 👕 CLOTHING ==========

1. Shirt           → ₹1200
2. Jeans           → ₹1800
3. Shoes           → ₹2500
4. Jacket          → ₹3000

Choose Item → """))

    case "Grocery":

        item_choice = int(input("""
========== 🥛 GROCERY ==========

1. Milk            → ₹50
2. Bread           → ₹40
3. Rice            → ₹100
4. Oil             → ₹150

Choose Item → """))

    case "Food Court":

        item_choice = int(input("""
========== 🍔 FOOD COURT ==========

1. Pizza           → ₹300
2. Burger          → ₹150
3. Fries           → ₹100
4. Cold Drink      → ₹80

Choose Item → """))


# ======================================================
# 🛍️ ITEM DETAILS
# ======================================================

match category_name:

    case "Electronics":

        match item_choice:

            case 1:
                item_name = "Headphones"
                item_price = 1500

            case 2:
                item_name = "Smart Watch"
                item_price = 3000

            case 3:
                item_name = "Keyboard"
                item_price = 800

            case 4:
                item_name = "Mouse"
                item_price = 500

            case _:
                print("Invalid Item !!")
                exit()

    case "Clothing":

        match item_choice:

            case 1:
                item_name = "Shirt"
                item_price = 1200

            case 2:
                item_name = "Jeans"
                item_price = 1800

            case 3:
                item_name = "Shoes"
                item_price = 2500

            case 4:
                item_name = "Jacket"
                item_price = 3000

            case _:
                print("Invalid Item !!")
                exit()

    case "Grocery":

        match item_choice:

            case 1:
                item_name = "Milk"
                item_price = 50

            case 2:
                item_name = "Bread"
                item_price = 40

            case 3:
                item_name = "Rice"
                item_price = 100

            case 4:
                item_name = "Oil"
                item_price = 150

            case _:
                print("Invalid Item !!")
                exit()

    case "Food Court":

        match item_choice:

            case 1:
                item_name = "Pizza"
                item_price = 300

            case 2:
                item_name = "Burger"
                item_price = 150

            case 3:
                item_name = "Fries"
                item_price = 100

            case 4:
                item_name = "Cold Drink"
                item_price = 80

            case _:
                print("Invalid Item !!")
                exit()


# ======================================================
# 🔢 QUANTITY
# ======================================================

item_quantity = int(input("\n🔢 Enter Quantity → "))

if item_quantity <= 0:
    print("❌ Invalid Quantity!")
    exit()


# ======================================================
# 💰 PRICE CALCULATION
# ======================================================

original_price = item_price * item_quantity


# ======================================================
# 💳 MEMBERSHIP + COUPON
# ======================================================

membership_status = int(input("\n💳 Active Membership? (1 = Yes / 0 = No) → "))

coupon_code = input("🎟️ Coupon Code → ").upper()


# Coupon Discount

if coupon_code == "SAVE10":
    coupon_discount = original_price * 0.10

elif coupon_code == "SAVE20":
    coupon_discount = original_price * 0.20

else:
    coupon_discount = 0


# Membership Discount

if membership_status == 1:
    membership_discount = original_price * 0.05

else:
    membership_discount = 0


# Bulk Discount

if item_quantity >= 10:
    bulk_discount = original_price * 0.20

elif item_quantity >= 5:
    bulk_discount = original_price * 0.10

else:
    bulk_discount = 0


# Total Discount

total_discount = coupon_discount + membership_discount + bulk_discount


# ======================================================
# 🚚 DELIVERY SECTION
# ======================================================

delivery_choice = int(input("""
========== 🚚 DELIVERY ==========

1. Normal        → ₹40
2. Fast          → ₹70
3. Premium       → ₹120

Choose Delivery → """))


match delivery_choice:

    case 1:
        delivery_type = "Normal"
        delivery_charge = 40

    case 2:
        delivery_type = "Fast"
        delivery_charge = 70

    case 3:
        delivery_type = "Premium"
        delivery_charge = 120

    case _:
        print("❌ Invalid Delivery Type!")
        exit()


# ======================================================
# 🧾 FINAL CALCULATIONS
# ======================================================

subtotal = original_price - total_discount

gst = subtotal * 0.18

final_amount = subtotal + gst + delivery_charge


# ======================================================
# 🏬 FINAL RECEIPT
# ======================================================

print(f"""
=================================================
            🏬 MEGA MALL RECEIPT
=================================================

👤 Customer           : {customer_name.title()}
🎂 Age                : {customer_age}

🛒 Category           : {category_name}
🛍️ Product            : {item_name}
🔢 Quantity           : {item_quantity}

-------------------------------------------------

💵 Original Price     : ₹{original_price:.2f}

🏷️ Coupon Discount    : ₹{coupon_discount:.2f}
💳 Membership Discount: ₹{membership_discount:.2f}
📦 Bulk Discount      : ₹{bulk_discount:.2f}

💸 Total Discount     : ₹{total_discount:.2f}

🚚 Delivery           : {delivery_type} +₹{delivery_charge:.2f}

🧾 GST (18%)          : ₹{gst:.2f}

-------------------------------------------------

💰 PAYABLE AMOUNT     : ₹{final_amount:.2f} /-

=================================================
🙏 Thank You For Shopping!
=================================================

""")
