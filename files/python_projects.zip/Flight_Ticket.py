# ==================================================
# ✈️ FLIGHT TICKET BOOKING SYSTEM
# ==================================================
# Features:
# ✅ Destination Selection
# ✅ Travel Class Selection
# ✅ Ticket Quantity
# ✅ Baggage Charges
# ✅ Age Discount
# ✅ Ticket Quantity Discount
# ✅ Optional Meal
# ✅ GST
# ✅ Final Receipt
# ==================================================


# ==================================================
# 👤 PASSENGER DETAILS
# ==================================================

passenger_name = input("👤 Passenger Name → ")

passenger_age = int(input("🎂 Passenger Age → "))

if passenger_age <= 0:
    print("❌ Invalid Age!")
    exit()


# ==================================================
# 🌍 DESTINATION SELECTION
# ==================================================

destination = int(input('''
========== 🌍 DESTINATION ==========

1. Delhi         → ₹3000
2. Mumbai        → ₹4500
3. Bangalore     → ₹5500
4. Dubai         → ₹15000
5. Singapore     → ₹22000

Choose Destination → '''))


match destination:

    case 1:
        destination_name = "Delhi"
        destination_fare = 3000

    case 2:
        destination_name = "Mumbai"
        destination_fare = 4500

    case 3:
        destination_name = "Bangalore"
        destination_fare = 5500

    case 4:
        destination_name = "Dubai"
        destination_fare = 15000

    case 5:
        destination_name = "Singapore"
        destination_fare = 22000

    case _:
        print("❌ Invalid Destination!")
        exit()


# ==================================================
# 💺 TRAVEL CLASS
# ==================================================

travel_class = int(input('''
========== 💺 TRAVEL CLASS ==========

1. Economy       → +₹0
2. Premium       → +₹1500
3. Business      → +₹5000
4. First Class   → +₹10000

Choose Class → '''))


match travel_class:

    case 1:
        travel_class_name = "Economy"
        travel_class_charge = 0

    case 2:
        travel_class_name = "Premium"
        travel_class_charge = 1500

    case 3:
        travel_class_name = "Business"

        travel_class_charge = 5000

    case 4:
        travel_class_name = "First Class"
        travel_class_charge = 10000

    case _:
        print("❌ Invalid Travel Class!")
        exit()


# ==================================================
# 🎫 NUMBER OF TICKETS
# ==================================================

ticket_qty = int(input("\n🎫 No. of Tickets → "))

if ticket_qty <= 0:
    print("❌ Invalid Ticket Quantity!")
    exit()


# ==================================================
# 🧳 BAGGAGE SECTION
# ==================================================

baggage = int(input('''
========== 🧳 BAGGAGE ==========

1. 10Kg        → Free
2. 20Kg        → +₹500
3. 30Kg        → +₹1000
4. 40Kg+       → +₹1500

Choose Baggage → '''))


match baggage:

    case 1:
        baggage_qty = "10Kg"
        baggage_charge = 0

    case 2:
        baggage_qty = "20Kg"
        baggage_charge = 500

    case 3:
        baggage_qty = "30Kg"
        baggage_charge = 1000

    case 4:
        baggage_qty = "40Kg+"
        baggage_charge = 1500

    case _:
        print("❌ Invalid Baggage Choice!")
        exit()


# ==================================================
# 💰 TRAVEL CHARGES
# ==================================================

# Flight + Class cost for all tickets
travel_cost = (destination_fare + travel_class_charge) * ticket_qty

# Add baggage separately
total_charges = travel_cost + baggage_charge


# ==================================================
# 👶 AGE DISCOUNT
# ==================================================

if passenger_age < 12:
    age_discount = total_charges * 0.25

elif passenger_age >= 60:
    age_discount = total_charges * 0.35

else:
    age_discount = 0


# ==================================================
# 🎟️ TICKET QUANTITY DISCOUNT
# ==================================================

if ticket_qty >= 8:
    ticket_discount = total_charges * 0.20

elif ticket_qty >= 4:
    ticket_discount = total_charges * 0.15

elif ticket_qty >= 2:
    ticket_discount = total_charges * 0.10

else:
    ticket_discount = 0


# Total discount
discount = age_discount + ticket_discount


# Discounted travel amount
travel_charges = total_charges - discount


# ==================================================
# 🍔 MEAL SECTION
# ==================================================

meal = int(input('''
🍔 Need Meal?

1 → Yes
0 → No

→ '''))


if meal == 1:

    meal_choice = int(input('''
========== 🍽️ CHOOSE MEAL ==========

1. Veg Meal          → ₹250
2. Non-Veg Meal      → ₹350

Choose Meal → '''))

else:
    meal_choice = 0


match meal_choice:

    case 1:
        meal_name = "Veg Meal"
        meal_charge = 250

    case 2:
        meal_name = "Non-Veg Meal"
        meal_charge = 350

    case _:
        meal_name = "No Meal"
        meal_charge = 0


meal_charges = meal_charge * ticket_qty


# ==================================================
# 🧾 GST + FINAL PRICE
# ==================================================

subtotal = travel_charges + meal_charges

gst = subtotal * 0.18

total_cost = subtotal + gst


# ==================================================
# ✈️ FINAL RECEIPT
# ==================================================

print(f'''
================================================
            ✈️ FLIGHT RECEIPT ✈️
================================================

👤 Passenger       : {passenger_name.title()}
🎂 Age             : {passenger_age}

🌍 Destination     : {destination_name}
💺 Travel Class    : {travel_class_name}
🎫 Tickets         : {ticket_qty}

🧳 Baggage         : {baggage_qty}
💰 Baggage Fee     : ₹{baggage_charge}

🍔 Meal            : {meal_name}
💰 Meal Charges    : ₹{meal_charges:.2f}

------------------------------------------------

💵 Travel Charges  : ₹{travel_cost:.2f}

🏷️ Age Discount    : ₹{age_discount:.2f}
🏷️ Ticket Discount : ₹{ticket_discount:.2f}

💸 Total Discount  : ₹{discount:.2f}

🧾 GST (18%)       : ₹{gst:.2f}

------------------------------------------------

💰 PAYABLE AMOUNT  : ₹{total_cost:.2f}

================================================
            🛫 Have a Safe Journey!
================================================''')