# Largest Number Finder

# Taking three integer inputs from the user
num1 = int(input("Enter Number 1: "))
num2 = int(input("Enter Number 2: "))
num3 = int(input("Enter Number 3: "))

# Determining the largest number among the three using if-elif conditions
if num1 > num2 and num1 > num3:
    result = num1

elif num2 > num1 and num2 > num3:
    result = num2

elif num3 > num1 and num3 > num2:
    result = num3

# Displaying the result in a more descriptive way
print(f"\nThe biggest number among {num1}, {num2}, and {num3} is: \n {result}")
