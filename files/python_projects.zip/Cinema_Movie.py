# ==========================================
# 🎬 MOVIE BOOKING SYSTEM
# ==========================================

# -------- Customer Details --------
customer_name = input("👤 Customer Name → ")


# -------- Movie Selection --------
movie = int(input("""
========== 🎥 MOVIE BOOKING ==========

1. Avengers          → ₹250
2. Batman            → ₹250
3. Spider-Man        → ₹300
4. Captain-America   → ₹300
5. Iron-Man          → ₹340

Choose Movie → """))


# -------- Movie Type --------
movie_type_choice = int(input("""
========== 🍿 MOVIE TYPE ==========

1. Normal            → ₹0 per ticket
2. 3D                → ₹20 per ticket
3. IMAX              → ₹50 per ticket
4. 4DX               → ₹75 per ticket

Choose Type → """))


# -------- Ticket Quantity --------
ticket_qty = int(input("\n🎫 No. of Tickets → "))


# -------- Booking Type --------
booking = int(input("""

========== 📱 BOOKING TYPE ==========

1. Online            → ₹20
2. Offline           → ₹35

Choose Booking → """))


# ==========================================
# Movie Details
# ==========================================

match movie:
    case 1:
        movie_name = "Avengers"
        movie_cost = 250

    case 2:
        movie_name = "Batman"
        movie_cost = 250

    case 3:
        movie_name = "Spider-Man"
        movie_cost = 300

    case 4:
        movie_name = "Captain-America"
        movie_cost = 300

    case 5:
        movie_name = "Iron-Man"
        movie_cost = 340

    case _:
        print("❌ Invalid Movie Choice!")
        exit()


# ==========================================
# Movie Type Details
# ==========================================

match movie_type_choice:

    case 1:
        movie_type = "Normal"
        movie_type_cost = 0

    case 2:
        movie_type = "3D"
        movie_type_cost = 20

    case 3:
        movie_type = "IMAX"
        movie_type_cost = 50

    case 4:
        movie_type = "4DX"
        movie_type_cost = 75

    case _:
        print("❌ Invalid Movie Type!")
        exit()


# ==========================================
# Ticket Validation
# ==========================================

if ticket_qty <= 0:
    print("❌ Invalid ticket quantity!")
    exit()


# ==========================================
# Booking Details
# ==========================================

match booking:

    case 1:
        booking_type = "Online"
        booking_price = 20

    case 2:
        booking_type = "Offline"
        booking_price = 35

    case _:
        print("❌ Invalid Booking Type!")
        exit()


# ==========================================
# Movie Price Calculation
# ==========================================

movie_total = (movie_cost + movie_type_cost) * ticket_qty


# -------- Ticket Discount --------

if ticket_qty >= 8:
    movie_discount = movie_total * 0.20

elif ticket_qty >= 4:
    movie_discount = movie_total * 0.10

else:
    movie_discount = 0


movie_total -= movie_discount


# -------- GST --------

gst = movie_total * 0.18

movie_total += gst


# ==========================================
# Meal Section
# ==========================================

meal = input("""

🍔 Need a Meal? (1/0)
→ """)


if meal == "1":

    food_choice = int(input("""

========== 🍟 CHOOSE MEAL ==========

1. Small         → ₹50
2. Medium        → ₹80
3. Large         → ₹120

Choose Meal → """))

    meal_qty = int(input("\nHow many meals? → "))

else:

    food_choice = 0
    meal_qty = 0


# ==========================================
# Meal Details
# ==========================================

match food_choice:

    case 1:
        meal_name = "Small"
        meal_cost = 50

    case 2:
        meal_name = "Medium"
        meal_cost = 80

    case 3:
        meal_name = "Large"
        meal_cost = 120

    case _:
        meal_name = "No Meal"
        meal_cost = 0


# ==========================================
# Meal Price Calculation
# ==========================================

meal_total = meal_cost * meal_qty


# -------- Meal Discount --------

if meal_qty >= 8:
    meal_discount = meal_total * 0.20

elif meal_qty >= 4:
    meal_discount = meal_total * 0.10

else:
    meal_discount = 0


meal_total -= meal_discount


# ==========================================
# Final Bill Calculation
# ==========================================

final_price = movie_total + meal_total + booking_price


# Meal display formatting

if meal_qty == 0:
    meal_display = "No Meal"

else:
    meal_display = f"{meal_qty} x {meal_name}"


# ==========================================
# Final Receipt
# ==========================================

print(f"""

==========================================
    🎬🍿 MOVIE TICKET RECEIPT 🍿🎬
==========================================

👤 Customer      : {customer_name.title()}

🎥 Movie         : {movie_name}
📽️ Type          : {movie_type}
🎫 Tickets       : {ticket_qty}

------------------------------------------

🎟️ Ticket Total  : ₹{movie_total:.2f}

🍔 Meal          : {meal_display}
💰 Meal Amount   : ₹{meal_total:.2f}

🏷️ Discount      : ₹{movie_discount + meal_discount:.2f}

📱 Booking       : {booking_type}
➕ Booking Fee   : ₹{booking_price}

🧾 GST (18%)     : ₹{gst:.2f}

------------------------------------------

💵 PAYABLE AMOUNT : ₹{final_price:.2f}

==========================================
    🎉 Enjoy your movie and snacks! 🍿
==========================================

""")
