customer_name = input("Enter Customer Name → ").upper()

phone_number = input("Enter Phone Number → ")
if len(phone_number) != 10 or not phone_number.isdigit():
    print("Invalid Phone Number !")
    exit()

order_id = customer_name[:4] + "05" + phone_number[-4:]

distance = int(input("Distance from Food Court (Km) → "))
if distance <= 0:
    print("Invalid Location !")
    exit()
elif 0 < distance <= 2:
    distance_charges = 0
elif 2 < distance <= 5:
    distance_charges = 30
elif 5 < distance <= 8:
    distance_charges = 50
else:
    print("Sorry we can't deliver your order.")
    exit()


restaurant_opt = int(input("""
====== RESTAURANT ======
1. Domino's
2. McDonald's
3. KFC
4. Burger King
→ """))

match restaurant_opt:
    case 1:
        restaurant_name = "Domino's"
    case 2:
        restaurant_name = "McDonald's"
    case 3:
        restaurant_name = "KFC"
    case 4:
        restaurant_name = "Burger King"
    case _:
        print("Invalid Restaurant Chosen!")
        exit()


match restaurant_name:

    case "Domino's":
        restaurant_menu = int(input("""
====== ITEMS MENU ======
1. Margherita Pizza → ₹200
2. Farmhouse Pizza → ₹350
3. Garlic Bread → ₹120
4. Coke → ₹60
→ """))

    case "McDonald's":
        restaurant_menu = int(input("""
====== ITEMS MENU ======
1. Burger → ₹150
2. Fries → ₹100
3. McAloo Tikki → ₹80
4. Cold Coffee → ₹90
→ """))

    case "KFC":
        restaurant_menu = int(input("""
====== ITEMS MENU ======
1. Chicken Bucket       → ₹499
2. Chicken Burger      → ₹180
3. Pepsi                → ₹60
4. French Fries         → ₹100
→ """))

    case "Burger King":
        restaurant_menu = int(input("""
====== ITEMS MENU ======
1. Whopper Burger       → ₹199
2. Crispy Veg Burger    → ₹129
3. French Fries         → ₹99
4. Chocolate Shake      → ₹120
→ """))


match restaurant_name:

    case "Domino's":

        match restaurant_menu:

            case 1:
                item_name = "Margherita Pizza"
                item_price = 200

            case 2:
                item_name = "Farmhouse Pizza"
                item_price = 350

            case 3:
                item_name = "Garlic Bread"
                item_price = 120

            case 4:
                item_name = "Coke"
                item_price = 60

            case _:
                print("Invalid Item !")
                exit()

    case "McDonald's":

        match restaurant_menu:

            case 1:
                item_name = "Burger"
                item_price = 150

            case 2:
                item_name = "Fries"
                item_price = 100

            case 3:
                item_name = "McAloo Tikki"
                item_price = 80

            case 4:
                item_name = "Cold Coffee"
                item_price = 90

            case _:
                print("Invalid Item !")
                exit()

    case "KFC":

        match restaurant_menu:

            case 1:
                item_name = "Chicken Bucket"
                item_price = 499

            case 2:
                item_name = "Chicken Burger"
                item_price = 180

            case 3:
                item_name = "Pepsi"
                item_price = 60

            case 4:
                item_name = "French Fries"
                item_price = 100

            case _:
                print("Invalid Item !")
                exit()

    case "Burger King":

        match restaurant_menu:

            case 1:
                item_name = "Whopper Burger"
                item_price = 199

            case 2:
                item_name = "Crispy Veg Burger"
                item_price = 129

            case 3:
                item_name = "French Fries"
                item_price = 99

            case 4:
                item_name = "Chocolate Shake"
                item_price = 120

            case _:
                print("Invalid Item !")
                exit()


item_qty = int(input("Quantity of items → "))
if item_qty <= 0:
    print("Invalid Item Quantity !")
    exit()

item_total = item_price * item_qty


coupon = input("Enter Coupon Code → ").upper()

match coupon:
    case "SAVE10":
        coupon_code = "SAVE10"
        coupon_discount = item_total * 0.1
    case "SAVE20":
        coupon_code = "SAVE20"
        coupon_discount = item_total * 0.2
    case "FOOD50":
        coupon_code = "FOOD50"
        coupon_discount = 50
    case _:
        coupon_code = "No Coupon"
        coupon_discount = 0

if item_qty >= 10:
    bulk_discount = item_total * 0.2
elif item_qty >= 5:
    bulk_discount = item_total * 0.1
else:
    bulk_discount = 0


discount_total = coupon_discount + bulk_discount
discounted_price = item_total - discount_total
gst = discounted_price * 0.18
final_amount = discounted_price + gst + distance_charges

payment = input(f"Pay amount of ₹{final_amount} using COD/UPI/Card: ").upper()

if payment == "UPI" or payment == "COD":
    payment_charges = 0
elif payment == "CARD":
    payment_charges = final_amount * 0.02
else:
    print("Invalid Payment Option !")
    exit()

payable_amount = final_amount + payment_charges

print(f"""
=====================================
        🍕 FOOD COURT
=====================================

👤 Customer : {customer_name}
📞 Phone No. : {phone_number}
🆔 Order ID : {order_id}

🏪 Restaurant : {restaurant_name}
🍔 Item : {item_name}
🔢 Quantity : {item_qty}

💰 Item Total : ₹{item_total}

🏷️ Coupon Discount : {coupon_code} ₹{coupon_discount:.2f} off
🏷️ Bulk Discount : ₹{bulk_discount:.2f} off
🤑 Total Discount : ₹{discount_total:.2f} off

🚚 Delivery Charges : +₹{distance_charges}
🧾 GST : +₹{gst:.2f}
🪙 Other : +₹{payment_charges:.2f} {payment} Charges

-------------------------------------

💵 PAYABLE AMOUNT : ₹{payable_amount:.2f} /-

=====================================
      """)
