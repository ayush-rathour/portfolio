# A Basic Temperature Converter (Celsius to Fahrenheit)

# Prompt the user to enter a temperature in Celsius
Temp_C = int(input("Enter the temperature in Celsius: "))

# Convert the Celsius temperature to Fahrenheit using the formula: (C × 9/5) + 32
Temp_F = (9/5 * Temp_C) + 32

# Display the result in a clear and formatted way
print(f"\nYou entered: {Temp_C}°C")
print(f"Converted Temperature: {Temp_F:.2f}°F")
