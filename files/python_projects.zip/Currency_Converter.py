# A Static Currency Converter

# Prompt the user to input the amount for conversion
amt = int(input("Enter the amount to convert: "))

# Display the menu for currency conversion options
print("\nSelect the currency conversion option:")
print(" 1. USD → INR")
print(" 2. EUR → INR")
print(" 3. USD → EUR")
print(" 4. INR → USD")
print(" 5. INR → EUR")
print(" 6. EUR → USD")

# Take user input for operation choice
opr = input("Enter your choice (1-6): ")

# Perform the currency conversion based on user's choice
if opr == "1":
    # USD to INR conversion
    cur = amt * 83
    print(f"\n{amt} USD is equal to {cur} INR")

elif opr == "2":
    # EUR to INR conversion
    cur = amt * 90
    print(f"\n{amt} EUR is equal to {cur} INR")

elif opr == "3":
    # USD to EUR conversion
    cur = amt * 0.93
    print(f"\n{amt} USD is equal to {cur} EUR")

elif opr == "4":
    # INR to USD conversion
    cur = amt * 0.012
    print(f"\n{amt} INR is equal to {cur} USD")

elif opr == "5":
    # INR to EUR conversion
    cur = amt * 0.011
    print(f"\n{amt} INR is equal to {cur} EUR")

elif opr == "6":
    # EUR to USD conversion
    cur = amt * 1.08
    print(f"\n{amt} EUR is equal to {cur} USD")

else:
    # If user enters an invalid option
    print("\nInvalid option selected! Please choose a number from 1 to 6.")
