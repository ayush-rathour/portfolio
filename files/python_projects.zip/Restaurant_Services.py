# Display Menu
print("""
===== MENU =====
1. Burger = $80
2. Pizza = $150
3. Fries = $50
4. Coke = $40
""")

# Take user input
order = int(input("Enter item number: "))
qty = int(input("Enter quantity: "))

# Select item using match-case
match order:
    case 1:
        item = "Burger"
        price = 80

    case 2:
        item = "Pizza"
        price = 150

    case 3:
        item = "Fries"
        price = 50

    case 4:
        item = "Coke"
        price = 40

    case _:
        print("Invalid order!")
        exit()

# Calculate bill
subtotal = price * qty
gst = subtotal * 0.18
final_bill = subtotal + gst

# Display bill
print(f"""
===== BILL =====

Item: {item}
Quantity: {qty}
Price per item: ${price}

Subtotal: ${subtotal}
GST (18%): ${gst:.2f}
Final Amount: ${final_bill:.2f}
""")