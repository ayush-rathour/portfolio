import random

secret_number = random.randint(1,3)

user_input = int(input("Guess a number between 1 to 3: "))

if (user_input < secret_number):
    print("You Guessed a lower number !")
elif (user_input > secret_number):
    print("You Guessed a higher number !")
elif (user_input == secret_number):
    print("Congratulations, you guessed the correct number.")
else:
    print("Something went wrong, Please enter a valid number.")