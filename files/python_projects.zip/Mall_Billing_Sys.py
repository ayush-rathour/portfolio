# INPUTS

customer_name = input("Customer name: ")

product_cat = int(input('''=== Product Category ===
1. Clothing → ₹500 per item
2. Electronics → ₹1500 per item
3. Grocery → ₹100 per item
4. Sports → ₹800 per item
→ '''))

product_qty = int(input("Product Quantity: "))

membership_type = int(input('''=== Membership Type ===
1. Gold → 20% discount
2. Silver → 10% discount
3. None → no discount
→ '''))

coupon_code = int(input('''=== Coupon ===
1. SAVE100 → ₹100 off
2. SAVE200 → ₹200 off
3. NO_COUPON
→ '''))


# PRODUCT CATEGORY

match product_cat:
    case 1:
        product_cat = "Clothing"
        product_cost = 500

    case 2:
        product_cat = "Electronics"
        product_cost = 1500

    case 3:
        product_cat = "Grocery"
        product_cost = 100

    case 4:
        product_cat = "Sports"
        product_cost = 800

    case _:
        product_cat = "Invalid Category"
        product_cost = 0


# TOTAL PRICE

total_price = product_cost * product_qty


# MEMBERSHIP

match membership_type:
    case 1:
        membership_type = "Gold"
        membership_discount = total_price * 0.20

    case 2:
        membership_type = "Silver"
        membership_discount = total_price * 0.10

    case 3:
        membership_type = "None"
        membership_discount = 0

    case _:
        membership_type = "Invalid Membership"
        membership_discount = 0


# COUPONS

match coupon_code:
    case 1:
        coupon_code = "SAVE100"
        coupon_discount = 100

    case 2:
        coupon_code = "SAVE200"
        coupon_discount = 200

    case 3:
        coupon_code = "NO_COUPON"
        coupon_discount = 0

    case _:
        coupon_code = "Invalid Coupon"
        coupon_discount = 0


# BULK DISCOUNT

if product_qty >= 20:
    bulk_discount = total_price * 0.10

elif product_qty > 5:
    bulk_discount = total_price * 0.05

else:
    bulk_discount = 0


# TOTAL DISCOUNT

discount = (
    membership_discount
    + coupon_discount
    + bulk_discount
)

discounted_price = total_price - discount


# GST

gst = discounted_price * 0.18

payable_amt = discounted_price + gst


# REWARD SYSTEM

if payable_amt > 5000:
    reward = "🎁 Free Gift Voucher Earned"

else:
    reward = "No Reward"


# BILL

print(f'''
====================================
          SHOPPING BILL
====================================

Customer Name   : {customer_name.upper()}
Category        : {product_cat}
Cost / Item     : ₹{product_cost}
Quantity        : {product_qty}

------------------------------------
Original Price  : ₹{total_price:.2f}

Membership Disc : ₹{membership_discount:.2f}
Coupon Discount : ₹{coupon_discount:.2f}
Bulk Discount   : ₹{bulk_discount:.2f}

Total Discount  : ₹{discount:.2f}

GST (18%)       : ₹{gst:.2f}
------------------------------------

PAYABLE AMOUNT    : ₹{payable_amt:.2f}

------------------------------------
Reward          : {reward}
====================================

     Thank you for shopping!
         Visit Again 😊

====================================
''')