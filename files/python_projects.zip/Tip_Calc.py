# 💰 Tip Calculator

base = float(input("💵 Enter the base amount: "))
tip_per = float(input("💡 Enter the tip percentage (%): "))

tip_amt = base * (tip_per / 100)
total = base + tip_amt

if base < 0:
    print("\n❌ Error: Base amount cannot be negative.")
elif tip_per > 100 or tip_per < 0:
    print("\n⚠️ Please enter a valid tip percentage (0% - 100%).")
else:
    print("\n✅ Tip Calculation Summary")
    print(f"🔸 Base Amount: ${base:.2f}") #.2f means float upto 2 decimal digits
    print(f"🔸 Tip ({tip_per}%): ${tip_amt:.2f}")
    print(f"💳 Total Amount: ${total:.2f} (including tip)")
