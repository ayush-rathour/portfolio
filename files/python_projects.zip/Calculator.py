# A Basic Calculator

# Welcome message
print("\n")
print("=== WELCOME TO THE PYTHON CALCULATOR ===")
print("----------------------------------------")

# Take two numbers as input
num_1 = int(input("Enter the first number: "))
num_2 = int(input("Enter the second number: "))

# Take the operation input
opr = input("Select Operation (+  -  *  /): ")
print("\n")

# Perform operations based on user input
if opr == "+":
    add = num_1 + num_2
    print("➤ Addition:")
    print(f"  {num_1} + {num_2} = {add}")

elif opr == "-":
    sub = num_1 - num_2
    print("➤ Subtraction:")
    print(f"  {num_1} - {num_2} = {sub}")

elif opr == "*":
    mult = num_1 * num_2
    print("➤ Multiplication:")
    print(f"  {num_1} × {num_2} = {mult}")

elif opr == "/":
    print("➤ Division:")
    if num_2 != 0:
        div = num_1 / num_2
        print(f"  {num_1} ÷ {num_2} = {div}")
    else:
        # Handle division by zero
        div = "Not possible as denominator can't be 0"
        print(f"  {num_1} ÷ {num_2} = {div}")

else:
    # Handle invalid operator
    print("⚠ Invalid Operation! Please enter one of: +  -  *  /")

# Thank you message
print("\n")
print("=== THANK YOU FOR USING THE CALCULATOR ===")
