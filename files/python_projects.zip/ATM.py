# Initial balance
balance = 5000

# Display ATM menu
print("""
===== ATM =====
1. Check Balance
2. Deposit
3. Withdraw
4. Exit
""")

# Take user input
choice = int(input("Enter your choice: "))

# Perform operation
match choice:

    case 1:
        print(f"Current Balance: ₹{balance}")

    case 2:
        deposit_amount = float(input("Enter amount to deposit: "))

        if deposit_amount > 0:
            balance += deposit_amount
            print("Deposit successful!")
            print(f"Current Balance: ₹{balance}")

        else:
            print("Invalid amount!")

    case 3:
        withdraw_amount = float(input("Enter amount to withdraw: "))

        if withdraw_amount <= 0:
            print("Invalid amount!")

        elif withdraw_amount <= balance:
            balance -= withdraw_amount
            print("Withdrawal successful!")
            print(f"Current Balance: ₹{balance}")

        else:
            print("Withdrawal failed!")
            print("Insufficient balance!")

    case 4:
        print("Thank you for using the ATM.")

    case _:
        print("Invalid operation!")
